import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import Mate from './components/Mate';
import Products from './components/section/Products';
import Footer from './components/Footer';
import PriceList from './components/Pricelist';
import Employees from './components/Addproducts';
import Addproducts  from './components/Addproducts'
import Payments from './components/Payment';
import Productprice from './components/NewPrices';


ReactDOM.render(
  <React.StrictMode>
    {/* <Payments/> */}
    <App/>
    {/* <Addproduct/> */}
    {/* <Employees/> */}
    {/* <Footer/> */}
  </React.StrictMode>
  ,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
