// import React , {Component} from 'react';
// import {Card, CardContent, Typography, Grid, FormControl, TextField,Paper, Icon} from "@material-ui/core";
// import AddBoxIcon from '@material-ui/icons/AddBox';
// import Button from '@material-ui/core/Button';
// import ReplayIcon from '@material-ui/icons/Replay';
// import FormatListBulletedIcon from '@material-ui/icons/FormatListBulleted';
// import { Style } from '@material-ui/icons';
// import EmailIcon from '@material-ui/icons/Email';
// import axios from 'axios';







// export default class ContactUs extends Component {
//   constructor(props){
//     super(props)
//     this.state = {
//       name : "",
//       eMail : "",
//       phoneNo : "",
//       feedBack:""
//     }
//   }

// onTextChange = (e) => {
//   //console.log(e.target.id)
//   this.setState({
//     [e.target.id]: e.target.value
//   })
// }

// handelSubmit = () => {
//   let feedBackSum = {
//     feedBack:this.state.message,
//     eMail : this.state.eMail,
//     phoneNum : this.state.phoneNo,
//     name : this.state.name,
    
//   }
//   axios.post("http://localhost:8080/feedback",feedBackSum)
//   .then((Response) => {
//     console.log("Saved Successfully")
//   })
// }
// componentDidMount(){
//   console.log("Hello")
// }



//   render(){
//       return(
//          <>
//          <div style = {{backgroundImage:`url("https://a-ec.co/wp-content/uploads/2019/01/42_1_contact-us.jpg")`,backgroundPosition: 'center',backgroundSize: 'cover',}}>
//           <Grid container spacing = {1} style = {{marginTop:10}}>
//             <Grid item xs = {1}/>
//             <Grid item xs = {10}>
//             {/* <EmailIcon style = {{fontSize:"700%",color:"#95B9C7"}}/> */}
//             <h1 style = {{fontFamily:"fontFamily"}}>Drop Your Message</h1>
//               <Grid container spacing = {1} style = {{marginTop:20}}>
//               <Grid item xs = {5}>
//                 <TextField
//                   fullWidth
//                   required
//                   id="name"
//                   label="Name"
//                   value = {this.state.name}
//                   onChange = {this.onTextChange}
//                   placeholder = "Enter your Name"
//                   variant="filled"
//                 />
//                 <br/>
//                 <br/>
//                 <br/>
//                 <TextField
//                   fullWidth
//                   required
//                   id="eMail"
//                   label="Email"
//                   value = {this.state.eMail}
//                   onChange = {this.onTextChange}
//                   placeholder = "Enter your E-Mail"
//                   variant="filled"
//                 />
//                 <br/>
//                 <br/>
//                 <br/>
//                 <TextField
//                   fullWidth
//                   id="phoneNo"
//                   label="Phone-No (Optional)"
//                   value = {this.state.phoneNo}
//                   onChange = {this.onTextChange}
//                   placeholder = "Enter your Phone-No"
//                   variant="filled"
//                 />
//                 <br/>
//                 <br/>
//                 <br/>
//                 <TextField
//                   required
//                   multiline
//                   fullWidth
//                   rows={4}
//                   id="feedBack"
//                   label="feedBack"
//                   value = {this.state.feedBack}
//                   onChange = {this.onTextChange}
//                   placeholder = "Enter your Message"
//                   variant="filled"
//                 />
//                 <br/>
//                 <br/>
//                 <center><Button variant="outlined" size="medium" color="gray"  onClick = {this.handelSubmit}>
//                   Submit
//                 </Button></center>
//                 <br/>
//                 <br/>
//               </Grid>
//               <Grid item xs = {2}/>
//               <Grid item xs = {5} >
//               <iframe
//                 width="100%"
//                 height="300"
//                 id="gmap_canvas"
//                 src="https://maps.google.com/maps?q=uki%20jaffna&t=&z=13&ie=UTF8&iwloc=&output=embed"
//                 frameborder="0"
//                 scrolling="no"
//                 marginheight="0"
//                 marginwidth="0"
//                 ></iframe>
//                 <div style = {{fontFamily:"monospace"}}>
//                     <h1>Contact Us:</h1>
//                     <h3>
//           Productprice          {/* &ensp;&ensp;&ensp;<span>Name : Daya Nanthan</span><br/> */}
//                     <span>E-Mail : <a href = "mailto:yarlmakket@gmail.com">yarlmakket@gmail.com</a></span><br/>
//                     <span>Tel/Whatsapp : +9476-880-1565 (Dayananthan)</span><br/>
//                     <span>Tel/Whatsapp : +9476-230-1565 (Anithvithushan)</span><br/>
//                     <span>Tel/Whatsapp : +9476-003-2652 (Rajinthan)</span><br/>
//                     </h3>
//                 </div>
//               </Grid>
//               </Grid>
//             </Grid>
//             </Grid>
//             </div>
//          </>
//       )
//   }
// }