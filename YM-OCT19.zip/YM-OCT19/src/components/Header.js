import React, { Component } from 'react'
import { AppBar, Button, Grid, Toolbar } from '@material-ui/core';
import {Link} from 'react-router-dom'
import {DataContext} from './Context'
import Carticn from './svg/YLogo.png'
import { Router } from '@material-ui/icons';
import Products from './section/Products'
import Details from './section/Details'
import Cart from './section/Cart'
import Payment from './section/Payment'
import Mate from './Mate'
import PriceList from './Pricelist'


const style={
    appbar:{
        background: "linear-gradient(135deg, #0079bf, black)",
        padding:8,
        height:105,
    },

    tophead: {
        marginLeft: 200,
        border: "tomato"
    },
    
    top:{
      margin:30,
      color:"white",
      padding:10,
      paddingLeft:-0,
  
    },
    logo:{
    width:250,
    height:180,
    marginLeft:100,
    marginTop:70

    },
    bar:{
      paddingLeft:2,
      marginLeft:5,
      borderRadius:20,
      
    },
    sch:{
      width:60,
      marginTop:200
    },
    home:{
      margin:0,
      paddingLeft:0,
      marginTop:70,
    },
    
    
    
    };
      


export class Header extends Component {
   
  
  static contextType = DataContext;

    // state = {
    //     toggle: false
    // }

    // menuToggle = () =>{
    //     this.setState({toggle: !this.state.toggle})
    // }


    render() {
        // const {toggle} = this.state;
        // const {cart} = this.context;
        return (
            <AppBar position="fixed" style={style.appbar}>
            <Toolbar style={style.bar}>
              <Grid container>
               <Grid xs={6}>
                    <Button style={style.lobut} href="/" >
                    <img src={Carticn} style={style.logo} />
                    </Button> 
                </Grid>
          
                      <Grid xs={6} style={style.home}>
                        <div style={style.tophead} >                     
                        <Button style={style.top} href="/home"><strong>HOME</strong></Button>
                        <Button style={style.top} href="/product"><strong>Our Product</strong></Button>
                        <Button style={style.top} href="/prices"><strong>Products Prices</strong></Button>
                        <Button style={style.top} href="/contact"><strong>Contact Us</strong></Button>
                        </div> 
                    </Grid>
                    </Grid>
                    </Toolbar>
        
            </AppBar>
            // <section>
            //     <Route exact path={["/home"]} component={Mate} />
            //     <Route path="/product" component={Products} exact />
            //     <Route path="/product/:id" component={Details} />
            //     <Route path="/cart" component={Cart} />
            //     <Route path="/payment" component={Payment} />
            //     <Route path="/prices" component={PriceList} />

            // </section>
        )
    }
}

export default Header





// import React, { Component } from 'react'
// import { AppBar, Button, Grid, Toolbar } from '@material-ui/core';

// // import Menu from './svg/bars-solid.svg'
// // import Close from './svg/times-solid.svg'
// // import CartIcon from './svg/shopping-cart-solid.svg'
// import {Link} from 'react-router-dom'
// import './css/Header.css'
// import {DataContext} from './Context'
// import Carticn from './svg/YLogo.png'
// import { Router } from '@material-ui/icons';
// import Products from './section/Products'
// import Details from './section/Details'
// // import {Route} from "react-router-dom"
// import Cart from './section/Cart'
// import Payment from './section/Payment'
// import Mate from './Mate'
// import PriceList from './Pricelist'
// // import Header from './Header'

// const style={
//     appbar:{
//         backgroundColor:" #263238" ,
//         padding:8,
//         height:105,
//     },
//     nav1:{
//         color: "white",
//         fontSize:15,
//         backgroundColor:"#424242"
//     },
//     nav2:{
//       color: "black",
//       fontSize:15,
//       backgroundColor:"#18ffff" ,
//       marginLeft:15
//     },
    
    
//     top:{
//       margin:30,
//       color:"white",
//       padding:10,
//       paddingLeft:-0,
//       fontFamily:"fontFamily",
    
//     },
//     logo:{
//     width:250,
//     height:180,
//     marginLeft:100,
//     marginTop:60

//     },
//     bar:{
//       paddingLeft:2,
//       marginLeft:5,
//       borderRadius:20,
      
//     },
//     sch:{
//       width:60,
//       marginTop:200
//     },
//     home:{
//       margin:0,
//       paddingLeft:0,
//       marginTop:70
//     },
    
    
    
//     };
      


// export class Header extends Component {
   
  
//   static contextType = DataContext;

//     // state = {
//     //     toggle: false
//     // }

//     // menuToggle = () =>{
//     //     this.setState({toggle: !this.state.toggle})
//     // }


//     render() {
//         // const {toggle} = this.state;
//         // const {cart} = this.context;
//         return (
//             <AppBar position="sticky" style={style.appbar}>
//             <Toolbar style={style.bar}>
//               <Grid container>
//                <Grid xs={6}>
//                     <Button style={style.lobut} href="/" >
//                     <img src={Carticn} style={style.logo} />
//                     </Button> 
//                 </Grid>
          
//                       <Grid xs={6} style={style.home}>
//                         <Button style={style.top} href="/home"><strong>HOME</strong></Button>
//                         <Button style={style.top} href="/product"><strong>Our Product</strong></Button>
//                         <Button style={style.top} href="/prices"><strong>Products Prices</strong></Button>
//                         <Button style={style.top} href="/contact"><strong>Contact Us</strong></Button>
//                         <Button style={style.nav1} href="/login"><strong>LOGIN</strong></Button>
//                         <Button style={style.nav2} href="./signin"><strong>SIGNUP</strong></Button>
//                     </Grid>
//                     </Grid>
//                     </Toolbar>
        
//             </AppBar>
//             // <section>
//             //     <Route exact path={["/home"]} component={Mate} />
//             //     <Route path="/product" component={Products} exact />
//             //     <Route path="/product/:id" component={Details} />
//             //     <Route path="/cart" component={Cart} />
//             //     <Route path="/payment" component={Payment} />
//             //     <Route path="/prices" component={PriceList} />

//             // </section>
//         )
//     }
// }

// export default Header




