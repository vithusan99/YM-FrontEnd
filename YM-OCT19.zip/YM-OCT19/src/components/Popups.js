
import { Button, Grid, Paper, TextField } from '@material-ui/core';
import React, {Component} from 'react';
import Apiservice from '../Services/Apiservice';
import { DataContext } from './Context';


export default class Popup extends Component{

    constructor(){
        super();
        this.state={
          products:[]
        }
        this.Addproduct = this.Addproduct.bind(this);
    }

    static contextType = DataContext;

    Addproduct=(e)=>{
        e.preventDefault()
        if(this.props.match.params.id){
        let products={
            id:this.state.id,
            name:this.state.name,
            quantity:this.state.quantity,
            price:this.state.price,
            img1:this.state.image1,
            cartegory:this.state.category,
            type:this.state.type,
            date:this.state.hireDat
        }
        Apiservice.retriveProduct(products)
        .then((Response)=>{
            console.log("HI")
            this.setState( {
                products:Response.data
            })
      })

      this.props.history.push("QD0tTak3Ap6r1")
      // window.location.reload()
        }else{
          let products={
            id:this.state.id,
            name:this.state.name,
            quantity:this.state.quantity,
            price:this.state.price,
            img1:this.state.image1,
            cartegory:this.state.category,
            type:this.state.type,
            date:this.state.hireDat
        }
        Apiservice.updateProduct(products)
        .then((Response)=>{
            console.log("HI")
            this.setState( {
                products:Response.data
            })
      })
        }
          
  }

    handleReset=()=>{
      this.setState({
        id:"",
        name:"",
        quantity:"",
        price:"",
        image1:"",
        category:"",
        type:"",
        date:"",
        description:""
      })
    }


     idChange = e => {
        this.setState({
          id:e.target.value
        })
      }

      nameChange=e=>{
        this.setState({
          name:e.target.value
        })
      }

      quantityChange=e=>{
        this.setState({
          quantity:e.target.value
        })
      }

      priceChange=e=>{
        this.setState({
          price:e.target.value
        })
      }

      image1Change=e=>{
        this.setState({
          image1:e.target.value
        })
      }

      categoryChange=e=>{
        this.setState({
          category:e.target.value
        })
      }

      typeChange=e=>{
        this.setState({
          type:e.target.value
        })
      }

      dateChange=e=>{
        this.setState({
          date:e.target.value
        })
      }

      descriptionChange=e=>{
        this.setState({
          description:e.target.value
        })
      }

         
    

    render(){
        // const{products}=this.state;

      //   const resetForm = () => {
      //     setValues(initialFValues);
      //     setErrors({})
      // }
        
        return(

            
            <Grid container style={{backgroundColor:"#e0f2f1"}}>
                <Grid xs={3}/>
                <Grid xs={6}>
                    <Paper style={{boxShadow:20,marginTop:300,marginBottom:100}}>
              <form style={{width:1200,margin:20,}}>
                    {/* onSubmit={handleSubmit} */}
                    <Grid container>
                      <Grid item xs={6} style={{paddingLeft:20}}>
                        <TextField
                          name="id"
                          label="Product id"
                          variant="standard"
                          value={this.state.id}
                          onChange={this.idChange}
                        /><br/>
                        <TextField
                          name="name"
                          label="Product Name"
                          variant="standard"
                          value={this.state.name}
                          onChange={this.nameChange}
                        /><br/>
                        <TextField
                          label="Quantity"
                          name="quantity"
                          variant="standard"
                          value={this.state.quantity}
                          onChange={this.quantityChange}
                        /><br/>
                        <TextField
                          label="Price"
                          name="price"
                          variant="standard"
                          value={this.state.price}
                          onChange={this.priceChange}
                        />
                         <TextField
                          label="Description"
                          name="description"
                          variant="standard"
                          value={this.state.description}
                          onChange={this.descriptionChange}
                        />
                      </Grid>
                      <Grid item xs={6}>
                        <TextField
                          label="Image URL"
                          name="img1"
                          variant="standard"
                          value={this.state.image1}
                          onChange={this.image1Change}
                        /><br/>

                        <TextField
                          name="gender"
                          label="Category"
                          variant="standard"
                          value={this.state.category}
                          onChange={this.categoryChange}
                        //   items={genderId}
                        /><br/>
                        <TextField
                          name="departmentId"
                          label="Type"
                          variant="standard"
                          value={this.state.type}
                          onChange={this.typeChange}
                        //   options={productService.getDepartmentCollection()}
                        /><br/>
                        <TextField
                          name="Date"
                          label="Date"
                          variant="standard"
                          value={this.state.date}
                          onChange={this.dateChange}
                        />

                        <div>
                          <Button type="submit" text="ADD" onClick={this.Addproduct}  > ADD </Button>
                          <Button text="Reset" color="default"  onClick={this.handleReset} >RESET</Button>
                        </div>￼
                        {/* onClick={resetForm}  */}
                      </Grid>
                    </Grid>
                  </form>
                  </Paper>
                  </Grid>
                  <Grid xs={3}/>
                  </Grid>
        )
    }
}
