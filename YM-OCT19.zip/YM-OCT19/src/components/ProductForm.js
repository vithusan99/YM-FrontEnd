// import React, { useState, useEffect, Component } from "react";
// import { Grid } from "@material-ui/core";
// import Controls from "../components/Controls";
// import { useForm, Form } from "../components/useForm";
// import * as productService from "../Services/productService";
// import Axios from "axios";
// import Apiservice from "../Services/Apiservice";
// // import { DataContext } from "./Context";

// const genderId = [
//   { id: "Dry fish", title: "Dry fish" },
//   { id: "other", title: "Other" },
// ];

// // const initialFValues = {
// //   id: "",
// //   name: "",
// //   quantity: "",
// //   price: "",
// //   chategory: "Dry fish",
// //   hireDate: new Date(),
// //   isPermanent: false,
// // };

// export default function ProductForm (props) {
     

//   const initialFValues = {
//     id: "",
//     name: "",
//     quantity: "",
//     prices: "",
//     category: "Dry fish",
//     type:"Type",

//     hireDate: new Date(),
//     isPermanent: false,
//     type:"",

//   };
        
//                 const { addOrEdit, recordForEdit } = props;
//                 const [products, setProducts] = React.useState('');
                


//                 const {
//                   values,
//                   setValues,
//                   // errors,
//                   // setErrors,
//                   handleInputChange,
//                   resetForm,
//                 } = useForm(initialFValues, true);

//                 const handleSubmit = (e) => {
//                   e.preventDefault();
//                   addOrEdit(values, resetForm);
//                   let product={
//                     name:values.name,
//                     id:values.id,
//                     quantity:values.quantity,
//                     price:values.prices,
//                     img1:values.img1,
//                     category:values.category,
//                     type:values.type,
//                   }
//     Apiservice.retriveProduct(product)
//     .then((Response)=>{
//       console.log("HI")
//       setProducts(Response.data)
//     })
//                 };
//                 //  const submitForm = (e)=>{
//                 //       e.preventDefault()
//                 //         let product={name:values.name,
//                 //                       id:values.id,
//                 //                       quantity:values.quantity,
//                 //                       price:values.price,
//                 //                       img1:values.img1,
//                 //                       category:values.category,
//                 //                       type:values.type,

//                 //                     }
//                 //       Apiservice.retriveProduct(product)
//                 //       .then((Response)=>{
//                 //         setProducts(Response.data)
//                 //       })
//                 //  };

//                 useEffect(() => {
//                   if (recordForEdit != null)
//                     setValues({
//                       ...recordForEdit,
//                     });
//                 }, [recordForEdit]);

//                 return (
//                   <Form onSubmit={handleSubmit}>
//                     {/* onSubmit={handleSubmit} */}
//                     <Grid container>
//                       <Grid item xs={6}>
//                         <Controls.Input
//                           name="id"
//                           label="Product id"
//                           value={values.id}
//                           onChange={handleInputChange}
//                           // error={errors.id}
//                         />
//                         <Controls.Input
//                           name="name"
//                           label="Product Name"
//                           value={values.name}
//                           onChange={handleInputChange}
//                           // error={errors.name}
//                         />
//                         <Controls.Input
//                           label="Quantity"
//                           name="quantity"
//                           value={values.quantity}
//                           onChange={handleInputChange}
//                           // error={errors.quantity}
//                         />
//                         <Controls.Input
//                           label="Price"
//                           name="price"
//                           value={values.prices}
//                           onChange={handleInputChange}
//                           // error={errors.price}
//                         />
//                       </Grid>
//                       <Grid item xs={6}>
//                         <Controls.Input
//                           label="Image URL"
//                           name="city"
//                           value={values.img1}
//                           onChange={handleInputChange}
//                         />

//                         <Controls.RadioGroup
//                           name="gender"
//                           label="Category"
//                           value={values.category}
//                           onChange={handleInputChange}
//                           items={genderId}
//                         />
//                         <Controls.Select
//                           name="departmentId"
//                           label="Type"
//                           value={values.type}
//                           onChange={handleInputChange}
//                           options={productService.getDepartmentCollection()}
//                           // error={errors.departmentId}
//                         />
//                         <Controls.DatePicker
//                           name="Date"
//                           label="Date"
//                           value={values.hireDate}
//                           onChange={handleInputChange}
//                         />

//                         <div>
//                           <Controls.Button type="submit" text="Submit"/>
//                           <Controls.Button text="Reset" color="default" onClick={resetForm} />
//                         </div>￼

//                       </Grid>
//                     </Grid>
//                   </Form>
//   );
 
// }






//                 // const validate = (fieldValues = values) => {
//                 //   let temp = { ...errors };
//                 //   if ("fullName" in fieldValues)
//                 //     temp.fullName = fieldValues.fullName ? "" : "This field is required.";
//                 //   if ("email" in fieldValues)
//                 //     temp.email = /$^|.+@.+..+/.test(fieldValues.email)
//                 //       ? ""
//                 //       : "Email is not valid.";
//                 //   if ("" in fieldValues)
//                 //     temp.mobile =
//                 //       fieldValues.mobile.length > 9 ? "" : "Minimum 10 numbers required.";
//                 //   if ("departmentId" in fieldValues)
//                 //     temp.departmentId =
//                 //       fieldValues.departmentId.length != 0 ? "" : "This field is required.";
//                 //   setErrors({
//                 //     ...temp,
//                 //   });

//                 //   if (fieldValues == values) return Object.values(temp).every((x) => x == "");
//                 // };