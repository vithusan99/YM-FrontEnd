
import { Button, Grid, Icon, IconButton, InputAdornment, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField } from '@material-ui/core';
import React, {Component} from 'react';
import SearchIcon from '@material-ui/icons/Search';
import { Link } from 'react-router-dom';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/Edit';
import ClearIcon from '@material-ui/icons/Clear';
import TableFooter from '@material-ui/core/TableFooter';
import TablePagination from '@material-ui/core/TablePagination';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';
import Apiservice from '../Services/Apiservice';
import { DataContext } from './Context';
import Popup from './Popups';




const style={
    search:{

    }
}
export default class Addproduct extends Component{
    constructor(){
        super();
        this.state={
             products:[]
        };

        // this.deleteProduct=this.deleteProduct.bind(this);

    }

    static contextType = DataContext;


    

    //  deleteProduct(id){
    //     Apiservice.deleteProduct(id)
    //         .then((Response)=>{
    //         console.log("HI")
    //         // this.setState( {
    //         //     products:Response.data
    //         // })
    //         window.location.reload()
    //   })
    // }


    componentDidMount(){

        Apiservice.fetchProduct()
            .then((Response)=>{
            console.log("HI")
            this.setState( {
                products:Response.data
            })
      })
    

  
  }

   
    render(){
        // const { count, page, rowsPerPage, onChangePage } = this.props;
        const {products,setProducts}=this.state




        return(
            <>
            <Grid container >
                <Grid xs={2}/>
                <Grid xs={8}>
                    <Paper style={{borderRadius:10,backgroundColor:'#a7ffeb',marginTop:150}}>
      

         <div style={style.search}>
           <Grid container>
             <Grid xs={6}>
                                    <TextField
                            id="input-with-icon-textfield"
                            label="Search"
                            type="search"
                            
                        />
                        </Grid>
                        <Grid xs={6}>
                        {/* <Link to="/addnew"> */}
                        <Button href="/QD0tTak3Ap6r1/addnew"><Icon className="fa fa-plus-circle" color="#0d47a1" />ADD NEW</Button>
                        {/* </Link> */}
                        </Grid>
                        </Grid>
             </div>


             <TableContainer>
                 <Table style={{minWidth:650}}>
                         <TableHead>
                         <TableRow>
                            <TableCell align="left"><b>Action</b></TableCell>
                            <TableCell align="left"><b>ID</b></TableCell>
                            <TableCell align="left"><b>Product Name</b></TableCell>
                            <TableCell align="left"><b>Price</b></TableCell>
                            <TableCell align="left"><b>Quantity</b></TableCell>
                            <TableCell align="left"><b>Category</b></TableCell>
                            <TableCell align="left"><b>Type</b></TableCell>
                            <TableCell align="left"><b>Description</b></TableCell>
                         </TableRow>
                         </TableHead> 
                         <TableBody>
                             {/* {console.log(products)} */}
                         {products.map((row) => (
                                <TableRow>
                                
                                <TableCell>
                                
                                <IconButton
                                href="/QD0tTak3Ap6r1"
                                onClick = {() => this.deleteProduct(row.id)}
                                
                                // onClick = {() => window.location.reload()}
                                >
                                <DeleteIcon
                                    
                                    color="default"
                                    align="left"
                                    inputProps={{ 'aria-label': 'DeleteIcon with default color' }}
                                />
                                </IconButton>


                                <Link to={`/QD0tTak3Ap6r1/addnew/${row.id}`}>
                                <IconButton 
                                // href="/QD0tTak3Ap6r1/addnew/${row.id}"
                                // onClick = {() => EditSave(row.id)}
                                >
                                    <EditIcon
                                    color="default"
                                    align="left"
                                    inputProps={{ 'aria-label': 'DeleteIcon with default color' }}
                                />
                                </IconButton>
                                </Link>
                                </TableCell>
                                <TableCell align="left">{row.id}</TableCell>
                                <TableCell align="left">{row.product}</TableCell>
                                <TableCell align="left">{row.price}</TableCell>
                                <TableCell align="left">{row.quantity}</TableCell>
                                <TableCell align="left">{row.category}</TableCell>
                                <TableCell align="left">{row.type}</TableCell>
                                <TableCell align="left">{row.description}</TableCell>
                                </TableRow>
                            ))}
                             </TableBody>  
                             {/* <TableFooter>
                                 <TablePagination
                                 rowsPerPageOptions={5}
                                 // colSpan={3}
                                 count={count}
                                 rowsPerPage={rowsPerPage}
                                 page={page}
                                 
                                 onChangePage={handleChangePage}
                                 onChangeRowsPerPage={handleChangeRowsPerPage}
                                 ActionsComponent={TablePaginationActions}
                               >
                                 

                                 </TablePagination>
                             </TableFooter> */}
                 </Table>

             </TableContainer>
                            </Paper>
                            </Grid>
                            <Grid xs={2}/>
                            </Grid>
                            {/* <Popup/> */}






        
        </>
        )
    }
}




//pagination

        // addNew=()=>{

        // }

        // const handleChangeRowsPerPage = (event) => {
        //     setRowsPerPage(parseInt(event.target.value, 10));
        //     setPage(0);
        //   };

        // const handleFirstPageButtonClick = (event) => {
        //   onChangePage(event, 0);
        // };
      
        // const handleBackButtonClick = (event) => {
        //   onChangePage(event, page - 1);
        //   console.log("Page" + page)
        // };
      
        // const handleNextButtonClick = (event) => {
        //   onChangePage(event, page + 1);
        //   console.log("Page" + page)
        // };
      
        // const handleLastPageButtonClick = (event) => {
        //   onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
        // };

        //buttons

              {/* <div className={classes.root}>
            <IconButton
              onClick={handleFirstPageButtonClick}
              disabled={page === 0}
              aria-label="first page"
            >
              {direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
            </IconButton>
            <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
              {direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
            </IconButton>
            <IconButton
              onClick={handleNextButtonClick}
              disabled={page >= Math.ceil(count / rowsPerPage) - 1}
              aria-label="next page"
            >
              {direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
            </IconButton>
            <IconButton
              onClick={handleLastPageButtonClick}
              disabled={page >= Math.ceil(count / rowsPerPage) - 1}
              aria-label="last page"
            >
              {direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
            </IconButton>
          </div> */}