import React from 'react';
import {Button, Box, makeStyles, AppBar,Toolbar, div, Grid, Card, Paper } from '@material-ui/core';
import Slideshow from './Slide';
import { red } from '@material-ui/core/colors';
import Star from './svg/five_pointed_star.svg'
// import Background from 'https://www.shutterstock.com/image-photo/abstract-blur-image-road-night-time-791096059';
  import './Mate.css' ;       


const mateStyle= makeStyles({
    slide:{
        marginTop:110,
        
    },

  
      root:{
          flexGrow:1,
        //   backgroundImage:`url(${Background})`
      },
      reet:{
        flexGrow:1,
        position:"absolute",
        marginLeft:900,
        textAlign:"right",
        top:-150
        
      },
      pap:{
          margin:40,
          textAlign:"center",
          paddingTop:20,
          backgroundColor:"#ffecb3"

      },
      des:{
        //   paddingTop:30
      },
      pap1:{
        marginTop:120,
        marginLeft:40,
        marginRight:40,
        textAlign:"center",
        paddingTop:20,
        backgroundColor:"#ffecb3"
      },
      star:{
        width:50,
        height:50
      },
      cont:{
          fontFamily:"Apple Color Emoji",
      }

      

})


 function Mate(){

    const style=mateStyle();

        return  (
            <>
                  <div>   
            <Slideshow className={style.slide}/>
            </div>
            
            <div className="tri" >
            <div className={style.reet}>
            {/* <Grid xs={12} container>
          <Grid xs={2}/> */}
        {/* <Grid xs={8} className={style.des}>
          <Box boxShadow={3}
            bgcolor="background.paper"
            m={0}
            p={0}
           className={style.box}>
        <Paper className={style.pap}>
                <div className={style.cont}>
                    <div className={style.sub}> */}
                        <h2>add a attractive intro</h2>
                        <p>wrugawiefhawekfjvakwehbwaehbarhvgr<br/>
                        erjtngwkrjgnkw3jrngkwj5rgnwkjrngnrgk3rg<br/>
                        jghqbwregfqwuergfqu3y4gtfoqu324ygfql3rhdfsthrthnrtndhtgndthynetynetymney5jnetyjneytjnetyh<br/>
                        waejrghq3ureygqo34uiygfqr3gbljewrh<br/>
                        arekgjerhbgqo34uyq3uto4ygtq3uy4gtkjerhbfesf<br/>
                        imsocoolguy soleavemealone bczurfire<br/>
                        wergsretjhnsrthsethsethsethse</p>
                    {/* </div>
                </div>
            </Paper>
            </Box>
        </Grid> */}
        {/* <Grid xs={2}/>
        </Grid> */}
            </div>
            </div>
            <div className={style.root}>
            <Grid container direction="row">
                    <Grid xs={2}/>
            <Grid  xs={8} className={style.des}>
                <Grid container spacing={0}>
                    <Grid xs={4}>
                        <Paper className={style.pap1} elevation={5}  style={{width:150},{height:300}}>
                            <div className={style.cont}>
                            <h2>FAST DELIVERY</h2>
                            <div >
                            <img src={Star} className={style.star}/>
                            <img src={Star}  className={style.star}/>
                            <img src={Star}  className={style.star}/>
                            </div>
                            </div>
                        </Paper>
                        </Grid>
                        <Grid xs={4}>
                        <Paper className={style.pap} elevation={15} style={{width:250},{height:400}}>
                            <div className={style.cont}>
                            <h2>MORE CUSTOMER-FOCUSED SERVICES</h2>
                            <div >
                            <img src={Star}  className={style.star}/>
                            <img src={Star}  className={style.star}/>
                            <img src={Star}  className={style.star}/>
                            </div>
                            </div>
                        </Paper>
                        </Grid>
                        <Grid xs={4}>
                        <Paper className={style.pap1} elevation={5} style={{width:150},{height:300}}>
                            <div className={style.cont}>
                            <h2>QUALITY </h2>
                            <div >
                            <img src={Star}  className={style.star}/>
                            <img src={Star}  className={style.star}/>
                            <img src={Star}  className={style.star}/>
                            </div>
                            </div>
                        </Paper>
                        </Grid>
            </Grid>
            </Grid>
            <Grid xs={2} />
            </Grid>
            </div>
        </>
        )
    
}

export default Mate