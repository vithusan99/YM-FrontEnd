import React from "react";
import ReactDOM from "react-dom";
import StripeCheckout from "react-stripe-checkout";
import axios from "axios";
import { toast } from "react-toastify";

// import "react-toastify/dist/ReactToastify.css";
// import "./styles.css";

toast.configure();

function Payments() {
  const [product] = React.useState({});

  async function handleToken(token, addresses) {
    const response = await axios.post("", { token, product });
    const { status } = response.data;
    console.log("Response:", response.data);
    if (status === "success") {
      toast("Success! Check email for details", { type: "success" });
    } else {
      toast("Something went wrong", { type: "error" });
    }
  }

  return (
    <div className="container" style={{}}>
      <div className="product">
        <h1>{products.name}</h1>
        <h3>On Sale · ${products.price}</h3>
      </div>
      <StripeCheckout
        stripeKey="pk_test_51HUFVPIfJ6z5pQk5vIVhsEZ1Y5Na3Hsc1zl3Asvd81gp36ez5gizmHhZioAoTqXxRKm9p7r9fvO4k9FoD21VnbFh00Mi1lFu5T"
        token={handleToken}
        amount={products.price * 100}
        name="YarlMakket"
        billingAddress
        shippingAddress
      />
    </div>
  );
}

export default Payments;