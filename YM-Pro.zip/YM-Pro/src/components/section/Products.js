import React, { Component } from 'react'
import { Card, CardHeader, CardMedia, CardContent, IconButton, Typography, CardActions, Button, makeStyles,Avatar, Grid, Box, Badge } from '@material-ui/core';
import AddShoppingCartIcon from '@material-ui/icons/AddShoppingCart';
import {Link} from 'react-router-dom'
import {DataContext} from '../Context'
import '../css/Products.css'
import Basket from '../svg/basket.png'
import Star from '../svg/five_pointed_star.svg'
import Apiservice from '../../Services/Apiservice';
import axios from'axios';



const style= {
//     tot:{
//         // width:"100%",
//         padding:10,
//         backgroundColor:"#ffd180",
//         marginBottom:-100
//     },
//     box:{
//         width:300,
//         // padding:100
//         margin:200,
//         marginBottom:-100
//     },

//     head:{
//         backgroundColor:"#d50000",
        
//     },
//     cont:{
//         backgroundColor:"#ffebee",
       
//     },
//     ttl:{
//         fontSize:20,
//         color:"#e91e63",
//         fontWeight:10
//     },
//     prc:{
//         color:"#e91e63",
//         paddingLeft:40,

//     },
    // media:{
    //     height:600,
    // },
    // star:{
    //     width:20,
    //     height:10
    // },
//     des:{
//         fontFamily:"fontFamily",
//         fontStyle:"italic",
//         alignItems:"flex-start"
//     },
//     type:{
//        fontFamily:"BlinkMacSystemFont",
//        color:"#880e4f"
//     },
    // but:{
    //     backgroundColor:"#d50000",
    //     fontWeight:40,
    //     textDecoration:"none"
    // },	
   

}




export class Products extends Component {
    constructor (){
        super();
        this.state={
            // products:[],
        };
    }

    static contextType = DataContext;

    
    componentDidMount(){
        // const dataCart = JSON.parse(localStorage.getItem('dataCart'));
        // if(dataCart !== null){
        //     this.setState({cart: dataCart});
        // }
        // const dataTotal = JSON.parse(localStorage.getItem('dataTotal'));
        // if(dataTotal !== null){
        //     this.setState({total: dataTotal});
        // }
        console.log("Helooooooo")

        // Apiservice.fetchProduct()
        // .then((response)=>{
        //     console.log(response)
        //     this.setState({
        //         // products:response.data
        //     })
        // }
        // )
    }

    render() {

        const {products,addCart,cart,total} = this.context;

        return (
            <>
            <div style={{backgroundColor:"#fff3e0"}} >
            <div className="icon" style={{position:"fixed"}}>
                {/* <span>{cart.length}</span> */}
                  <Badge badgeContent={cart.length} className="bas" >
                  <Link to="/cart">
                       <Button> <img src={Basket} className="basket" /></Button>
                       </Link>
                 </Badge>
            </div>
            <div  id="product" style={{marginTop:200}}>
            {
                products.map(product =>(
                    <div className="card" key={product.id}  >
                        <Box boxShadow={20}  >
                        <Card  >
                            <CardHeader 
                            action={
                                    
                                <IconButton aria-label="setting" style={{backgroundColor:"#9fa8da"}}  onClick={()=> addCart(product.id)} >
                                     <AddShoppingCartIcon />
                                </IconButton>
                            }
                            subheader={product.product}
                            />
                            <Link to={`/product/${product.id}`}>
                                <img src={product.image1} style={{height:250,width:400,marginLeft:4,borderRadius:10}}/>
                            </Link>
                            <CardContent className={style.cont} >
                                        <Typography varient="body2" component="tt" className="img">
                                            {product.subtitle}
                                        </Typography>
                                    <br/>
                                        <Typography varient="h4" component="dp" className={style.des}>
                                        <img src={Star} style={{width:40,height:40}}/>
                                            {product.description}
                                        </Typography><br/><br/>
                                        <Typography varient="h3" component="tp" className={style.type}>
                                        Type: {product.type}
                                        </Typography>
                            </CardContent>
                            <CardActions>
                            <Grid container spacing={1}>
                                <Grid item xs={6}>
                                <Button size="small" className={style.but} ><Link to="/payment"  className="txt">BUY</Link></Button>
                                </Grid>
                                <Grid item xs={6} style={{marginTop:18,color:"red"}} >
                                {/* <Button size="small" className={style.but} ><Link to="/payment"  className="txt">OFFER</Link></Button> */}
                                <Typography varient="body2" component="pc" className={style.prc}>
                                    <h2><center>Rs.{product.price}</center></h2>
                                </Typography>
                                </Grid>
                                </Grid>
                            
                            </CardActions>

                        </Card>
                        </Box>
                        </div>
                )
             )
            }
       </div>
       </div>
       </>
        )
    }
}

export default Products



{/* <div id="product">
               {
                   products.map(product =>(
                       <div className="card" key={product._id}>
                           <Link to={`/product/${product._id}`}>
                               <img src={product.src} alt=""/>
                           </Link>
                           <div className="content">
                               <h3>
                                   <Link to={`/product/${product._id}`}>{product.title}</Link>
                               </h3>
                               <span>${product.price}</span>
                               <p>{product.description}</p>
                               <button onClick={()=> addCart(product._id)}>Add to cart</button>
                           </div>
                       </div>
                   ))
               }
            </div> */}
