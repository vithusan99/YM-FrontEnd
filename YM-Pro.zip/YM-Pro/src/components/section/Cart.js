import React, { Component } from 'react'
import {DataContext} from '../Context'
import {Link} from 'react-router-dom'
// import Colors from './Colors'
import '../css/Details.css'
import '../css/Cart.css'
import inc from '../svg/incrs.png'
import dec from '../svg/incrs2.png'


export class Cart extends Component {
    static contextType = DataContext;

    componentDidMount(){
        this.context.getTotal();
    }
    
    render() {
        const {cart,increase,reduction,removeProduct,total} = this.context;
        if(cart.length === 0){
            
            
            return <h2 style={{textAlign:"center",marginTop:300,marginBottom:350}}><strong>Nothings Product</strong></h2>
            
        }else{
            return (
                <>
                <div className="tot">
                    {
                        cart.map(item =>(
                            <div className="details-cart" key={item.id}>
                                  <div className="delete" onClick={() => removeProduct(item.id)}>X</div>
                                <img src={item.image1} alt="erf" className="src"/>
                                <div className="box">
                                    <div className="row">
                                        <h2>{item.title}</h2>
                                        <span>Rs {item.price * item.count} .00</span>
                                    </div>
                                    {/* <Colors colors={item.colors}/> */}
                                    <p>{item.descriptions}</p>
                                    {/* <p>{item.content}</p> */}
                                    <div className="amount">
                                    {/* <img src={inc}> */}
                                        <button className="count"  onClick={() => reduction(item.id)}>  </button>
                                        {/* </img> */}
                                        <span>{item.count} Kg</span>
                                        {/* <img src={dec}> */}
                                        <button className="count" onClick={() => increase(item.id)}>  </button>
                                        {/* </img> */}
                                    </div>
                                </div>
                            </div>
                        ))
                    }
                    </div>
                    <div className="total">
                        <Link to="/payment">Payment</Link>
                        <h3>Total: Rs {total}.00</h3>
                    </div>
                
                </>
                )
            }
        }
}

export default Cart
