import React from 'react'
import {Button, Box, makeStyles, AppBar,Toolbar, Grid } from '@material-ui/core';
import CollectionsBookmarkOutlinedIcon from '@material-ui/icons/Collections'

const new1Style=makeStyles({
botbar:{
    position:"relative",
    backgroundColor:"#263238",
    color:"white",
    width:"100%",
    height:300,
    fontSize:20,
    bottom:0,
    left:0
},
lbot:{
  color:"white",
  textAlign:"center",
},
head:{
  fontFamily:"Helvetica Neue",
  fontSize:15,
  top:400,
  textAlign:"center",

},
tot:{
  margin:0,
  padding:0,
}

} );           


function Footer(){

  const classes= new1Style();
return(

       
                <div className={classes.tot}>
                <Box className={classes.botbar}  >
                <Grid container>
                  <Grid xs={3}  >
                      <p>Contact Us</p>
                      <p> Social media links :</p>
                      <p> E-mail Address :</p>
                  </Grid>
                  <Grid xs={3}/>
                  <Grid xs={3}><p>About Us :</p></Grid>
                  </Grid>
                  {/* <div className={classes.lbot} > */}
                    
                    <h3 className={classes.head} >
                    <hr style={{width:900,color:"white",margin:"auto",}}/>
                    © 2020  YarlMakket. All Rights Reserved.
                    <hr style={{width:700,color:"white",margin:"auto"}}/>
                    </h3>
                    
                  {/* </div> */}
                </Box>
                 </div>
)

}
export default Footer